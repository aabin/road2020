#include "lasio.h"
#include "structs.h"
#include <string>
#include <iostream>
#include <Segment.h>

using std::string;
using std::cout;
using std::endl;

int main()
{
    Time timer;
    //input parameters
    const string test_file_path = "/home/joey/Data/mls1.las";
    const string road_cloud_path = "/home/joey/Data/mls_road.las";
    const string edge_cloud_path = "/home/joey/Data/mls_edge.las";

    float grid_size, planar_threshold, angle_threshold, height_threshold, refine_distance_threshold, alpha_shape;

    unsigned int type; // 0-ALS, 1-MLS

    type = 1;

    if (type == 0)
    {
        grid_size = 1.0;
        planar_threshold = 0.005;
        angle_threshold = 5;
        height_threshold = 0.05;
        refine_distance_threshold = 0.035;
        alpha_shape = 5;
    }
    else if (type == 1)
    {
        grid_size = 0.5;
        planar_threshold = 0.0004;
        angle_threshold = 5;
        height_threshold = 0.025;
        refine_distance_threshold = 0.025;
        alpha_shape = 5;
    }

    //medium files
    vector<Point3DI> local_point_repo, refined_cloud, edge;
    Point3D global_shift, local_minB, local_maxB;
    vector<vector<Grid> > chess;
    vector<vector<uint> > regions, alpha;
    vector<zBoundary> boundarys;

    Lasio lasio;
    lasio.readLasFile(test_file_path, local_point_repo, global_shift, local_minB, local_maxB);

    Segment segment;
    segment.segmentToGrid(local_point_repo, global_shift, grid_size, local_minB, local_maxB, chess);

    //release local-coord point set
    vector<Point3DI>().swap(local_point_repo);

    segment.ccltGridInfo(chess);

    segment.regionGrow(chess, planar_threshold, angle_threshold, height_threshold, regions);

    segment.adjustRegions(regions, chess);

    vector<Point3DI> opoint, rpoint;
    for (int i = 0; i < chess.size(); ++i) {
        for (int j = 0; j < chess[0].size(); ++j) {
            for (int k = 0; k < chess[i][j].point_number; ++k) {
                Point3DI cpt = chess[i][j].vPoints[k];
                cpt.inten = chess[i][j].info.residual * 10000;
                opoint.push_back(cpt);
                cpt.inten = regions[i][j];
                rpoint.push_back(cpt);
            }
        }
    }
    lasio.writeLasFile("/home/joey/Data/display.las", opoint, global_shift);
    lasio.writeLasFile("/home/joey/Data/regions.las", rpoint, global_shift);

    //manually input the largest label
    ushort largest_label = 0;
    do{
        cout << "#input the largest region label:  ";
        std::cin >> largest_label;
    }
    while(largest_label <= 0 || largest_label >= 6);

    segment.chooseRegions(regions, largest_label, alpha);

    segment.refineRoad(chess, alpha, refine_distance_threshold, refined_cloud);

    segment.extractBoundary(alpha_shape, refined_cloud, chess, boundarys, local_minB, edge);

    lasio.writeLasFile(road_cloud_path, refined_cloud, global_shift);
    lasio.writeLasFile(edge_cloud_path, edge, global_shift);

    cout << timer.timeSpent() << endl;

    return 0;
}